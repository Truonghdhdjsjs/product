<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class MyConfig extends BaseConfig
{
	public $keyLogin = "LOGINED";
	public $keyURL = "KEYURL";
	public $keyCart = "CART";
}