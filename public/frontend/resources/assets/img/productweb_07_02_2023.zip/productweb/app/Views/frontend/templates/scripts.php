
    <!-- Start Script -->
    <script src="<?= base_url() ?>/frontend/resources/assets/js/jquery-1.11.0.min.js"></script>
    <script src="<?= base_url() ?>/frontend/resources/assets/js/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?= base_url() ?>/frontend/resources/assets/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>/frontend/resources/assets/js/templatemo.js"></script>
    <script src="<?= base_url() ?>/frontend/resources/assets/js/custom.js"></script>
    <!-- End Script -->